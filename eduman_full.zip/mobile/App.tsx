import React, { useEffect, useState } from "react";
import { Text, View, FlatList, TouchableOpacity } from "react-native";
import axios from "axios";

const API = "http://YOUR_LOCAL_IP:3000"; // replace with your server URL reachable by phone

export default function App() {
  const [papers, setPapers] = useState<any[]>([]);

  useEffect(()=>{ fetchPapers() }, []);

  async function fetchPapers() {
    try {
      const res = await axios.get(`${API}/api/exams`);
      setPapers(res.data);
    } catch (err) {
      console.log(err);
    }
  }

  return (
    <View style={{ flex: 1, padding: 20, paddingTop: 60 }}>
      <Text style={{ fontSize: 24, fontWeight: "bold" }}>Edu Man (mobile)</Text>
      <FlatList
        data={papers}
        keyExtractor={(i)=>i.id}
        renderItem={({ item }) => (
          <TouchableOpacity style={{ padding: 12, backgroundColor: "#fff", marginTop: 12, borderRadius: 8 }}>
            <Text style={{ fontWeight: "600" }}>{item.title}</Text>
            <Text style={{ color: "#666" }}>{item.examBoard} • {item.subject}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
