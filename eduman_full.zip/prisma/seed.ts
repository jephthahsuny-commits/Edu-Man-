import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main(){
  await prisma.user.createMany({
    data: [
      { email: "student@example.com", name: "Student One", role: "student", passwordHash: "" },
      { email: "teacher@example.com", name: "Teacher One", role: "teacher", passwordHash: "" }
    ],
  });

  await prisma.examPaper.create({
    data: {
      title: "Sample Math Paper 2021",
      examBoard: "Cambridge",
      level: "O-Level",
      year: 2021,
      subject: "Mathematics",
      fileUrl: "/papers/sample-math-2021.pdf",
      paperType: "past"
    }
  });

  await prisma.ebook.create({
    data: {
      title: "Intro to Physics (Sample)",
      authors: ["A. Author"],
      subject: "Physics",
      level: "High School",
      fileUrl: "/ebooks/physics-sample.pdf",
      formats: ["pdf"]
    }
  });

  console.log("Seed complete.");
}

main().catch(e=>{ console.error(e); process.exit(1); }).finally(()=>process.exit());
