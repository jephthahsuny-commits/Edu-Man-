import { signIn } from "next-auth/react";
import { useState } from "react";
import { useRouter } from "next/router";

export default function Login() {
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  async function handle(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const res = await signIn("credentials", { redirect: false, email, password: pwd });
    if (res?.ok) router.push("/dashboard");
    else setError("Invalid login credentials");
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-sky-50 to-white">
      <form onSubmit={handle} className="w-full max-w-md bg-white shadow-md rounded-lg p-6">
        <h2 className="text-2xl font-semibold mb-4">Sign in to Edu Man</h2>
        {error && <div className="text-red-600 mb-2">{error}</div>}
        <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input type="password" className="input mt-2" placeholder="Password" value={pwd} onChange={e=>setPwd(e.target.value)} />
        <button className="w-full mt-4 py-2 rounded bg-blue-600 text-white">Sign in</button>
      </form>
    </div>
  );
}
