import { useState } from "react";
import { signIn } from "next-auth/react";

export default function Signup() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [pwd, setPwd] = useState("");
  const [county, setCounty] = useState("");
  const [role, setRole] = useState("student");
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !pwd) return setError("Email and password required.");
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, name, password: pwd, county, role })
    });
    const json = await res.json();
    if (res.ok) {
      await signIn("credentials", { redirect: true, email, password: pwd });
    } else {
      setError(json?.error || "Signup failed");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-sky-50 to-white">
      <form onSubmit={handleSubmit} className="w-full max-w-md bg-white shadow-md rounded-lg p-6">
        <h2 className="text-2xl font-semibold mb-4">Create your Edu Man account</h2>
        {error && <div className="text-red-600 mb-2">{error}</div>}
        <input className="input" placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} />
        <input className="input mt-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input type="password" className="input mt-2" placeholder="Password" value={pwd} onChange={e=>setPwd(e.target.value)} />
        <input className="input mt-2" placeholder="County" value={county} onChange={e=>setCounty(e.target.value)} />
        <select className="input mt-2" value={role} onChange={e=>setRole(e.target.value)}>
          <option value="student">Student</option>
          <option value="teacher">Teacher</option>
          <option value="parent">Parent</option>
        </select>
        <button className="w-full mt-4 py-2 rounded bg-blue-600 text-white">Sign up & continue</button>
      </form>
    </div>
  );
}
