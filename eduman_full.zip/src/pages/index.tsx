import Header from "../components/Header";
import prisma from "../lib/prisma";

export default function Home({ papers }) {
  return (
    <div>
      <Header />
      <main className="max-w-6xl mx-auto p-6">
        <section className="bg-white p-6 rounded shadow mb-6">
          <h1 className="text-3xl font-bold">Edu Man</h1>
          <p className="text-gray-600 mt-2">Past papers, ebooks, accredited courses, AI tutor & live classes.</p>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-3">Sample past papers</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {papers.map(p => (
              <a key={p.id} href={`/paper/${p.id}`} className="card">
                <div className="font-semibold">{p.title}</div>
                <div className="text-sm text-gray-500">{p.examBoard} • {p.subject} • {p.year}</div>
              </a>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

export async function getServerSideProps() {
  const papers = await prisma.examPaper.findMany({ take: 6, orderBy: { year: "desc" }});
  return { props: { papers } };
}
