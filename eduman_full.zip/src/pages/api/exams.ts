import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../lib/prisma";

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  const { exam_board, subject, year } = req.query;
  const where: any = {};
  if (exam_board) where.examBoard = String(exam_board);
  if (subject) where.subject = String(subject);
  if (year) where.year = Number(year);
  const papers = await prisma.examPaper.findMany({ where, orderBy: { year: "desc" }});
  res.json(papers);
}
