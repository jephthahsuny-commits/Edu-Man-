import type { NextApiRequest, NextApiResponse } from "next";
import { ragAnswer } from "../../../lib/ai";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end();
  const { prompt, paperId } = req.body;
  try {
    const answer = await ragAnswer(prompt, paperId);
    res.json({ answer });
  } catch (err: any) {
    console.error(err);
    res.status(500).json({ error: err.message || "AI error" });
  }
}
