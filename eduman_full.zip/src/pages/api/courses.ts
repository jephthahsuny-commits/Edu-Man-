import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../lib/prisma";

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  if (req.method === "GET") {
    const courses = await prisma.course.findMany({ where: { approvalStatus: "approved" }});
    res.json(courses);
  } else if (req.method === "POST") {
    const { title, provider, description } = req.body;
    const c = await prisma.course.create({ data: { title, provider, description }});
    res.status(201).json(c);
  } else res.status(405).end();
}
