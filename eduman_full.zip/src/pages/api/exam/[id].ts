import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../../lib/prisma";

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  const { id } = req.query;
  const paper = await prisma.examPaper.findUnique({ where: { id: String(id) }, include: { questions: true }});
  res.json(paper);
}
