import type { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // TODO: integrate your video provider (Daily.co / Twilio / Zoom)
  return res.json({ joinUrl: "https://meet.example.com/demo", provider: "demo" });
}
