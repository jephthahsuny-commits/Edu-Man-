import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../lib/prisma";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { county } = req.query;
  const where: any = {};
  if (county) where.county = String(county);
  const events = await prisma.event.findMany({ where });
  res.json(events);
}
