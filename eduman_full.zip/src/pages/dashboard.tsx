import Header from "../components/Header";
import { getSession, useSession } from "next-auth/react";

export default function Dashboard({ }) {
  const { data: session } = useSession();

  return (
    <div>
      <Header />
      <main className="max-w-6xl mx-auto p-6">
        <h1 className="text-2xl font-bold">Welcome back{session?.user?.name ? `, ${session.user.name}` : ""}</h1>

        <section className="grid grid-cols-3 gap-4 mt-6">
          <div className="card col-span-2">
            <h3 className="font-semibold">Continue learning</h3>
            <div className="mt-3">
              <p className="text-sm text-gray-600">Quick links to your courses, last papers, and AI assistant.</p>
            </div>
          </div>

          <aside className="card">
            <h4 className="font-medium">Local events</h4>
            <p className="text-sm text-gray-600 mt-2">Events in your county — enable location to see nearby classes.</p>
          </aside>
        </section>
      </main>
    </div>
  );
}

export async function getServerSideProps(ctx) {
  const session = await getSession(ctx);
  if (!session) {
    return { redirect: { destination: '/auth/login', permanent: false } };
  }
  return { props: { } };
}
