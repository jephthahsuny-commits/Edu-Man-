import Header from "../components/Header";
import prisma from "../lib/prisma";

export default function Admin({ pendingCourses = [] }) {
  return (
    <div>
      <Header />
      <main className="max-w-6xl mx-auto p-6">
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <section className="mt-6">
          <h2 className="font-semibold">Pending Courses</h2>
          <div className="mt-3">
            {pendingCourses.map(c => (
              <div key={c.id} className="p-3 bg-white rounded shadow mb-2">
                <div className="flex justify-between">
                  <div>
                    <div className="font-semibold">{c.title}</div>
                    <div className="text-sm text-gray-500">{c.provider}</div>
                  </div>
                  <div className="space-x-2">
                    <button className="px-3 py-1 bg-green-600 text-white rounded">Approve</button>
                    <button className="px-3 py-1 bg-red-600 text-white rounded">Deny</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

export async function getServerSideProps(){
  const pendingCourses = await prisma.course.findMany({ where: { approvalStatus: "pending" }});
  return { props: { pendingCourses } };
}
