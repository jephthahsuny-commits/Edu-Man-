import Header from "../../components/Header";
import PdfReader from "../../components/PdfReader";
import AiWidget from "../../components/AiWidget";
import prisma from "../../lib/prisma";

export default function PaperPage({ paper }) {
  return (
    <>
      <Header />
      <main className="max-w-6xl mx-auto p-6 grid grid-cols-3 gap-6">
        <div className="col-span-2 card">
          <h2 className="text-xl font-semibold">{paper.title}</h2>
          <PdfReader fileUrl={paper.fileUrl} />
        </div>
        <aside className="col-span-1">
          <AiWidget paperId={paper.id} />
        </aside>
      </main>
    </>
  );
}

export async function getServerSideProps({ params }) {
  const paper = await (await import("../../lib/prisma")).default.examPaper.findUnique({ where: { id: params.id }});
  return { props: { paper } };
}
