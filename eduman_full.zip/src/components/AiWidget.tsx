import { useState } from "react";

export default function AiWidget({ paperId }: { paperId?: string }) {
  const [prompt, setPrompt] = useState("");
  const [answer, setAnswer] = useState<string | null>(null);

  async function ask() {
    const res = await fetch("/api/ai/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, paperId })
    });
    const json = await res.json();
    setAnswer(json.answer);
  }

  return (
    <div className="card">
      <h3 className="font-semibold">AI Study Assistant</h3>
      <textarea className="input mt-2" rows={4} value={prompt} onChange={e=>setPrompt(e.target.value)} />
      <button onClick={ask} className="mt-2 px-3 py-1 bg-blue-600 text-white rounded">Ask</button>
      {answer && <div className="mt-3 p-3 bg-gray-50 text-sm rounded">{answer}</div>}
    </div>
  );
}
