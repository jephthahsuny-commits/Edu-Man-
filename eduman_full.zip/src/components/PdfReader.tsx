import dynamic from "next/dynamic";
import React from "react";

const ReactPDF = dynamic(() => import("react-pdf/dist/esm/entry.webpack"), { ssr: false });

export default function PdfReader({ fileUrl }: { fileUrl: string }) {
  return (
    <div className="border rounded p-2">
      <a href={fileUrl} target="_blank" rel="noreferrer" className="text-blue-600">Open PDF</a>
      <div className="mt-3 text-sm text-gray-500">PDF preview placeholder (use react-pdf to render pages).</div>
    </div>
  );
}
