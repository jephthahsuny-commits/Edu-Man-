import Link from "next/link";
import { useSession, signOut } from "next-auth/react";

export default function Header(){
  const { data: session } = useSession();
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/"><img src="/logo.png" alt="Edu Man" className="h-9"/></Link>
        <nav className="flex items-center gap-4">
          <Link href="/exams">Papers</Link>
          <Link href="/courses">Courses</Link>
          <Link href="/ebooks">Ebooks</Link>
          <Link href="/events">Events</Link>
          <Link href="/admin">Admin</Link>
          {session?.user ? (
            <>
              <Link href="/dashboard">Dashboard</Link>
              <button onClick={()=>signOut()} className="px-3 py-1 border rounded">Sign out</button>
            </>
          ) : (
            <>
              <Link href="/auth/login" className="px-3 py-1 border rounded">Sign in</Link>
              <Link href="/auth/signup" className="px-3 py-1 bg-sky-500 text-white rounded">Sign up</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
