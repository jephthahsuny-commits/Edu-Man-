import fetch from "node-fetch";
import prisma from "./prisma";

const OPENAI_KEY = process.env.OPENAI_API_KEY;

export async function callOpenAI(systemPrompt: string, userPrompt: string) {
  if (!OPENAI_KEY) throw new Error("OPENAI_API_KEY not set");
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${OPENAI_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      max_tokens: 700,
      temperature: 0.2
    })
  });
  const json = await res.json();
  return json?.choices?.[0]?.message?.content;
}

export async function ragAnswer(prompt: string, paperId?: string) {
  let context = "";
  if (paperId) {
    const paper = await prisma.examPaper.findUnique({ where: { id: paperId }});
    if (paper) {
      context += `Paper: ${paper.title} (${paper.examBoard} ${paper.year || ""})\n`;
      const qs = await prisma.question.findMany({ where: { paperId }, take: 10 });
      context += qs.map(q => `Q${q.seq}: ${q.text}`).join("\n\n");
    }
  }
  const system = "You are Edu Man's AI tutor. Use the context to produce accurate, step-by-step answers and cite sources.";
  const userPrompt = `Context:\n${context}\n\nUser question:\n${prompt}`;
  const answer = await callOpenAI(system, userPrompt);
  // log
  await prisma.aiInteraction.create({ data: { prompt, response: answer || "no answer", sources: { paperId }, modelName: "openai" }});
  return answer;
}
