# Edu Man — Full scaffold

This repository is a full scaffold for the Edu Man app (web + mobile) including backend APIs, Prisma schema, seed data, AI stubs, and an Expo mobile starter.

## Quick start (web)

1. Create a `.env` file with:
```
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/eduman
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=change_this_to_a_long_random_string
OPENAI_API_KEY=sk-...
```

2. Install dependencies:
```
npm install
```

3. Generate Prisma client & run migrations:
```
npx prisma generate
npx prisma migrate dev --name init
npm run seed
```

4. Run dev server:
```
npm run dev
```

Open http://localhost:3000

## Mobile app
```
cd mobile
npm install
expo start
```
Use Expo Go on your phone and set `API` in `mobile/App.tsx` to your server IP.

## Notes
- Replace placeholder PDFs in `public/papers` and `public/ebooks` with licensed content.
- Configure OpenAI key to enable AI features.
- Integrate a video provider for live classes.
- Do not commit `.env` with secrets.
